# Enterprise-Management-Dashboard-V2

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/faraz34root/Enterprise-Management-Dashboard-V2)