import type { Employee, AttendanceRecord } from './types';

export async function getAllEmployees(): Promise<Employee[]> {
  try {
    const mockEmployees: Employee[] = [
      { id: 1, name: 'Иванов Иван Иванович', position: 'Инженер', department: 'Производство' },
      { id: 2, name: 'Петров Петр Петрович', position: 'Технолог', department: 'Разработка' },
      { id: 3, name: 'Сидорова Анна Павловна', position: 'Менеджер', department: 'Управление' },
    ];
    
    return Promise.resolve(mockEmployees);
  } catch (error) {
    console.error('API Error:', error);
    return [];
  }
}

export async function getEmployeeAttendance(
  startDate: string,
  endDate: string
): Promise<AttendanceRecord[]> {
  try {
    const mockAttendance: AttendanceRecord[] = [
      {
        id: 1,
        employee_id: 1,
        date: '2024-03-01',
        time_in: '09:00',
        time_out: '18:00',
        hours_worked: 8
      }
    ];

    return Promise.resolve(mockAttendance);
  } catch (error) {
    console.error('API Error:', error);
    return [];
  }
}